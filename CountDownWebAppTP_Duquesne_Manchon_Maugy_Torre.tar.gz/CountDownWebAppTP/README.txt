Répartition du travail :

	Alexandre Duquesne : index.jsp
	Alexandre Manchon + Brendon Torre: SQLiteJDBC + WebSocket
	Xavier Maugy + Brendon Torre : Les tests